EXTRA_CLASSPATH=./hudup-toolkit.jar

. env.sh

eval $JAVA_CMD net.hudup.Toolkit