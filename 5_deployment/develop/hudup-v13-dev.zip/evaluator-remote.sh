EXTRA_CLASSPATH=./hudup-evaluator.jar

. env.sh

eval $JAVA_CMD net.hudup.EvaluatorRemote