cd ../..
. env.sh
eval $JAVA_CMD net.hudup.core.logistic.console.ConsoleCP
cd tools/cp
