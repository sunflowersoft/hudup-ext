./server2.sh service
