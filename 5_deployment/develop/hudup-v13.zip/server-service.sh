./server.sh service
