. env.sh
eval $JAVA_CMD net.hudup.core.client.RemoteServerCP
