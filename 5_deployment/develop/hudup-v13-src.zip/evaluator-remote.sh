. env.sh

eval $JAVA_CMD net.hudup.EvaluatorRemote