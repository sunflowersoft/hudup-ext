. env.sh
eval $JAVA_CMD net.hudup.server.ext.EvaluatorCPList
