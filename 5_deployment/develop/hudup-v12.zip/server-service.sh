./server.sh service
