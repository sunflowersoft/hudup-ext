./env.sh

$JAVA_CMD net.hudup.Evaluator $1 $2 $3 $4