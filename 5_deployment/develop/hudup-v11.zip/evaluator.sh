./env.sh

$JAVA_CMD net.hudup.Evaluator