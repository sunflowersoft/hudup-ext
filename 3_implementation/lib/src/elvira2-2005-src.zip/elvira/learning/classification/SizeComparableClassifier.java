package elvira.learning.classification;

/**
 * This interface defines a Classifier with wich it makes sense to compare it
 * according to its size, with which is understood the number of parameters that this
 * classifier requires to be estimated from data (or manually specified).
 * 
 * @author dalgaard
 *
 */
public interface SizeComparableClassifier extends Classifier {
	public long size();
}
