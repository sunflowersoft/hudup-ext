/*
 * Copyright (C) 2005-2013 Schlichtherle IT Services.
 * All rights reserved. Use is subject to license terms.
 */
/**
 * The TrueVFS Extension PaceManager implemetation.
 *
 * @author Christian Schlichtherle
 */
@javax.annotation.Nonnull @javax.annotation.ParametersAreNonnullByDefault
package de.schlichtherle.truezip.extension.pace;
