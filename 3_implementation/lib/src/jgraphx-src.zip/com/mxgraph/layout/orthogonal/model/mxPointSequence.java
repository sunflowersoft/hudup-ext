/**
 * $Id: mxPointSequence.java,v 1.1 2008-10-02 12:49:11 gaudenz Exp $
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.mxgraph.layout.orthogonal.model;

/**
 *
 */
public class mxPointSequence
{

}
